n = int(input())
ct = [0]*n
for i in range(n-1):
    k = int(input())
    ct[k-1] = 1

for i in range(n):
    if ct[i]==0: 
        print(i+1)
        break