import math
n, k = [int(v) for v in input().split()]
t = (240-k)//5
x = int(math.sqrt(2*t))
#print(x)
if (x*x+x>2*t): print(min(x-1, n))
else: print(min(x, n))
