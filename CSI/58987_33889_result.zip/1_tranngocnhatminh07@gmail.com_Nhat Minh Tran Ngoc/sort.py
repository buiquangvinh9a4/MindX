a = [int(v) for v in input().split()]

a.sort()
print(*a[::-1])