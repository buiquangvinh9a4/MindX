#include <bits/stdc++.h>
using namespace std;
const int MAXN=105;
int n, t; string s;
typedef map<string, int> msi;
typedef pair<int, string> pii;

msi cnt;
vector<string> ct[1005];

void solve() {
    cnt.clear();
    for (int i=0; i<1005; i++) ct[i].clear();
    cin >> n;
    for (int i=0; i<n; i++){
        cin >> s >> t;
        cnt[s] += t;
    }

    cout << cnt.size() << '\n';
    
    msi::iterator itr;
    for (itr=cnt.begin(); itr!=cnt.end(); itr++) ct[itr->second].push_back(itr->first);

    for (int i=1005; i>0; i--) {
        for (int j=0; j<ct[i].size(); j++) cout << ct[i][j] << " " << i << '\n';
    }
}

int main() {
    ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int t;
    cin >> t;
    while (t--) solve();
}