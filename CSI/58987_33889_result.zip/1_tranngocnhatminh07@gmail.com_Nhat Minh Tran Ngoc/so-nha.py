n = int(input())
x = (n+1)//2
print(x*x)