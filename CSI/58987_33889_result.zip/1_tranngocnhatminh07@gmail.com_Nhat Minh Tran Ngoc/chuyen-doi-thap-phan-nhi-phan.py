n = int(input())
if (n==0): print(0)
else:
    r = ""
    while n>1:
        r = str(n%2) + r
        n //= 2

    print('1' + r)