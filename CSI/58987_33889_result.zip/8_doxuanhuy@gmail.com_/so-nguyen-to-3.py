def is_prime(n):
    if n <= 1 or n >= 10**12:
        return False
    primes = [True] * (n + 1)
    primes[0] = False
    primes[1] = False
    for i in range(2, int(n**0.5) + 1):
        if primes[i]:
            for j in range(i * i, n + 1, i):
                primes[j] = False
    return primes[n]
def is_prime(n):
    if n <= 1:
        return False
    primes = [True] * (n + 1)
    primes[0] = False
    primes[1] = False
    for i in range(2, int(n**0.5) + 1):
        if primes[i]:
            for j in range(i * i, n + 1, i):
                primes[j] = False
    return primes[n]

num = int(input())

if is_prime(num):
    print( "yes")
else:
    print( "no")