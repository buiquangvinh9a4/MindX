input_string = input()
string_list = input_string.split()
number_list = [int(x) for x in string_list]
sorted_numbers = sorted(number_list, reverse=True)
print(" ".join(map(str, sorted_numbers)))