
a = input()
b = input()
c = input()
d = input()


try:
    a = float(a)
    b = float(b)
    c = float(c)
    d = float(d)
except ValueError:
    print("Nhap vao khong hop le")
    exit()


if a > 0 and b > 0 and c > 0 and d > 0:
    if (a == b and c == d) or (a == c and b == d) or (a == d and b == c):
        print("YES")
    else:
        print("NO")
else:
    print("NO")