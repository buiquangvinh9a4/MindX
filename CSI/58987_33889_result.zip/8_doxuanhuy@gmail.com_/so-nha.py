n = int(input())

if n % 2 == 0:
    
    tong = sum(range(2, n+1, 2))
    tong = sum(range(1, n+1, 2))
else:
    

print( tong)