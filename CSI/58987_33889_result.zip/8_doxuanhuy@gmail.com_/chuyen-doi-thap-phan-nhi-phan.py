nums = int(input())
accept = bin(nums)
print(accept)