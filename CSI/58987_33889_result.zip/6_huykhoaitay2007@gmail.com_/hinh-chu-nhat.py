a = int(input())
b = int(input())    
c = int(input())
d = int(input())

if a == b:
    if c == d:
        print('YES')
    else:
        print('NO')
elif a == c:
    if b == d:
        print('YES')
    else:
        print('NO')
elif a == d:
    if b == c:
        print('YES')
    else:
        print('NO')
    