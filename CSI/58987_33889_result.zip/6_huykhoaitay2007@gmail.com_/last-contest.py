a = int(input())
b = bin(a)[:2]
print(b)