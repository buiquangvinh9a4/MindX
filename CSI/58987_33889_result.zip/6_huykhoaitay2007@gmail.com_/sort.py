n = input()
n = n.split()

for i in range(len(n)):
    n[i] = int(n[i])

n_sort = sorted(n, reverse=True)

for number in n_sort:
    print(number, end = ' ')