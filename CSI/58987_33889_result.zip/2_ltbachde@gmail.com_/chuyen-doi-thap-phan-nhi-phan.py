n = int(input())

s = []

while n > 0:
    temp = n % 2
    s.append(temp)
    n = n //2
    
for i  in range (len(s) -1, -1, -1):
    print(s[i], end = '')