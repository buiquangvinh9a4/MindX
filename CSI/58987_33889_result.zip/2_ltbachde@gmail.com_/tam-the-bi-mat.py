n = int(input())

arr = []
arr_true = []
for i in range (1, n+1, 1):
    arr_true.append(i)

for i in range (0,n-1,1):
    a = int(input())
    arr.append(a)

for i in arr:
    for j in arr_true:
        if i == j:
            arr_true.remove(j)

for number in arr_true:
    print(number)