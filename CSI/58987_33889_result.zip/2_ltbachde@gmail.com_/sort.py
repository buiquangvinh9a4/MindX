s = input()
s = s.split()

for i in range (len(s)):
    s[i] = int(s[i])
ss = sorted(s, reverse = True)

for n in ss:
    print(n, end = ' ')