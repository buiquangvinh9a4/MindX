import math

a = int(input())

if(a<2):
    print("no")
else:
    b = int(math.sqrt(a))
    prime = True
    for i in range(2,b+1):
        if (a%i == 0):
            prime = False
            break
    if prime:
        print("yes")
    else:
        print("no")
            
