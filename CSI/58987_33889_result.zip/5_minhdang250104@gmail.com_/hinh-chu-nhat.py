a = int(input())
b = int(input())
c = int(input())
d = int(input())

if (a==c)&(b==d)|(a==b)&(c==d)|(a==d)&(b==c):
    print("YES")
else:
    print("NO")