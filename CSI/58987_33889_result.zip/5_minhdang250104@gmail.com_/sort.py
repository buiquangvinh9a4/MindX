dic = input()
dic = dic.split()
for i in range(len(dic)):
    dic[i]=int(dic[i])
sorted_dic = sorted(dic, reverse=True)
for a in sorted_dic:
    print(a, end=' ')