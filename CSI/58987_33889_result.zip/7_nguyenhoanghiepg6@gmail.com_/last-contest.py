import math
n, k = input().split()
n = int(n)
k = int(k)
a = 24*((240-k)/60)

def ptbh(a,b,c):
    a = int(a)
    b = int(b)
    c = int(c)
    delta = b**2 - 4 * a * c
    print(int((-(b) + math.sqrt(delta))/(2*a) ))
ptbh(1,1,-24*((240-k)/60))
