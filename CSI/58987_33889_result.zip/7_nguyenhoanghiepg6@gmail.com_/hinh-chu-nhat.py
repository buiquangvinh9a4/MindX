a = int(input())
b = int(input())
c = int(input())
d = int(input())
if ((a == b) and (c == d)):
    print("YES")
elif ((a == c) and (b == d)):
    print("YES")
elif ((a == d)and(b == c)):
    print("YES")
else:
    print("NO")