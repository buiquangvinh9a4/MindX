a = int(input())
while a>0:
    b = a%2
    a = a//2
    print(b,end = "")
