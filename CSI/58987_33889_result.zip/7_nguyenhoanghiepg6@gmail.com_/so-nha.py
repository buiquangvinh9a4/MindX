n = int(input())
if n%2==1:
    print(int((n+1)*((((n-1)/2)+1)/2)))
if n%2==0:
    print(int(n*((((n-2)/2)+1)/2)))
    
