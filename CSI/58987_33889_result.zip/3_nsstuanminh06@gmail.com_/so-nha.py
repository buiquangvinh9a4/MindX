n = int(input())
# print(n)
sum = 0

for i in range(1, n+1, 2):
    # print(i)
    sum = sum + i
print(sum)
