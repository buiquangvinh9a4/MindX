array = input()
n = array.split(" ")

for value in range(len(n)):
    n[value] = int(n[value])
    
n_sort = sorted(n, reverse=True)
for i in n_sort:
    print(i, end=" ")