import math
n = int(input())
check = True
if n < 2:
    check = False
else:
    for i in range(2, int(math.sqrt(n))+ 1):
        if n % i == 0:
            check = False

if check == True:
    print("yes")
else:
    print("no")