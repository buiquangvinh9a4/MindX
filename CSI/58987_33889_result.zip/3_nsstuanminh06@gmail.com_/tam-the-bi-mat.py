n = input()
# print(n)
sample_arr = [0] * len(n)
print(len(sample_arr))