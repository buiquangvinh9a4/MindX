def counting_sort(arr):
    
    if len(arr) <= 1:
        return
    
    max_val = max(arr)
 
    count = [0] * (max_val+1)
    for el in arr:
        count[el] += 1
 
    index = 0
    for i in range(max_val+1):
        for j in range(count[i]):
            arr[index] = i
            index += 1
            
lst = []
for i in range(0, 4):
    n = int(input())
    lst.append(n)

counting_sort(lst)

if lst[0] == lst[1] and lst[2] == lst[3]:
    print("YES")
else:
    print("NO")