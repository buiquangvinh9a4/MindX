n=int(input())
a=[]
for i in range (n-1):
    a.append(int(input()))
print((int((n+1)*(n/2)))-sum(a))