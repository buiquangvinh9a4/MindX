n = int(input())
if n == 0:
    print(0)
else:
    k = []
    while (n>0):
        a = int(float(n%2))
        k.append(a) 
        n = (n-a)/2 

    ans = ""

    k.reverse() 

    for i in k:
        ans += str(i)
    print(ans)
