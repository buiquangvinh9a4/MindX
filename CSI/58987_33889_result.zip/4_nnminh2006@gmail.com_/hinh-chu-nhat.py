a = int(input("a="))
b = int(input("b="))
c = int(input("c="))
d = int(input("d="))
k = 0
if a==b:
    k+=1
if a==c:
    k+=1
if a==d:
    k+=1    
if b==c:
    k+=1
if b==d:
    k+=1
if c==d:
    k+=1
if k ==2:
    print("YES")
if k !=2:
    print("NO")
