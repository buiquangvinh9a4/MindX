s = input()
s= s.split()

for i in range (len(s)):
    s[i]=int(s[i])
    
s_sort=sorted(s, reverse=True)
for number in s_sort:
    print(number, end = ' ')
