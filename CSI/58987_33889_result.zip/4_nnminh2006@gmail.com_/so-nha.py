a = int(input())
answer = 0
for i in range(0, a + 1):
    if i % 2 != 0:
        answer += i
print(answer)