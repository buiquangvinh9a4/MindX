import random

# s = "0" + str(random.randint(10000, 99999))

number = random.randint(100000, 999999)
print(number)