import os 
def checkValidUsername(username, path):
    lst_usernames = []
    with open(path, "r") as fr:
        for line in fr:
            user = line.split(";")[0]
            lst_usernames.append(user)
    
    if username in lst_usernames:
        return True
    return False

def mainMenu():
    
    print("=== MINDX BANKING ===")
    print("1. Create new account")
    print("2. Login")
    print("3. Exit")
    print("=====================")

def signUp():
    path = "Project_Banking/list_accounts.txt"
    print("=== SIGN UP ===")
    
    # -> username
    while True:
        username = input("- Username: ")
        if not(checkValidUsername(username, path)):
            if len(username) >= 4:
                break
            else:
                print("Username must be at least 4 characters")
        else:
            print("Username invalid. Please rechoice!")

    # -> password
    while True:
        password = input("- Password: ")
        if len(password) >= 6 and " " not in password:
            break
        else:
            if len(password) < 6:
                print("Password must be at least 6 characters")
            if " " in password:
                print("Password cannot contain space")

    # -> repeat password:
    while True:
        repeat_password = input("- Repeat password: ")
        if repeat_password == password:
            break
        else:
            print("Password does not match!")
    
    # -> STK: ID
    import random
    id = random.randint(100000, 999999)

    # -> Full name
    while True:
        full_name = input("- Full name: ")
        if len(full_name) >= 4:
            break
        else:
            print("Full name must be at least 4 characters")
    
        
    # Correct Account
    with open(path, "a") as fw:
        fw.write(f"{username};{password};{id};{full_name};0\n")
        print(f"Finish. Welcome to MindX Banking, {full_name}")
    

    

