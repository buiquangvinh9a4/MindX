from function import *
import os 

choice = 0
os.system("clear")
mainMenu()
while True:
    choice = int(input("Enter your choice: "))
    if choice == 1:
        os.system("clear")
        signUp()
        mainMenu()
    elif choice == 2:
        pass
    elif choice == 3:
        break
    else:
        print("Invalid choice")